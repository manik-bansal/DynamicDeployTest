$ProgressPreference="SilentlyContinue"
$WarningPreference="SilentlyContinue"

Import-Module $PSScriptRoot\Modules\SharePointPnPPowerShellOnline.psd1

Set-Location -path $PSScriptRoot

#Source Site Url whose template needs to be provisioned
$sourceSiteUrl = 'https://in8jilas.sharepoint.com/sites/9090'

$AppId = '01c9a311-5305-428c-b716-493f7fda466d'
$AppSecret = 'tSeaBceMLic8Q8xzIIlaqJ9D6JP90CgEQg2kz7l2FWM='

#XML Template File Name
$xmlFileName = 'dynamicTemplate.xml'

try {
    #Getting Destination Site Url in variable $in
    $in = 'https://in8jilas.sharepoint.com/sites/Demo132'

    #Connect and Apply Provisioning Template to destination site ($in)
    function  applyProvisioningTemplate() {
 
        Write-Output "Incoming request for '$in'"

        #Connecting to Destination Site
        Connect-PnPOnline -AppId $AppId -AppSecret $AppSecret -Url $in
        Write-Output "Connected to destination site"
 
        Write-Output "Applying Provisioning template to destination site"
        
        #Applying XML Provisioning Template to Destination Site
        Apply-PnPProvisioningTemplate -Path ".\$xmlFileName" -ClearNavigation
 
        Write-Output "Template provisioning completed"
    }
  
    #Connect to Source Site and get Provisioning Template
    function getProvisioningTemplate() {

        #Connecting to Source Site
        Connect-PnPOnline -AppId $AppId -AppSecret $AppSecret -Url $sourceSiteUrl
        Write-Output "Connected to source site"
  
        Write-Output "Getting Provisioning template from Source Site"
        
        #Getting Provisioning Template from Source Site
        Get-PnPProvisioningTemplate -Out ".\$xmlFileName" -Handlers All -Force
        Write-Output "Generated the Provisioning template"

        applyProvisioningTemplate 
    }
    #Calling function getProvisioningTemplate to Generate Provisioning Template from Source Site
    
	getProvisioningTemplate
}

catch {
    Write-Output $_.Exception.Message
}